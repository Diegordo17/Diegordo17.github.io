//Adquirir campos
let usernameP = document.getElementById('UserName')
let edadR = document.getElementById('EdadRegistrada')
let emailR = document.getElementById('correoRegistrado')
let JJ = document.getElementById('juegosRegistrados')
let AD = document.getElementById('ArribaDerecha')